// filename : /feature/finance.c
// Modified and annotated by cloudr@dtslz 2000.5.13

// can_afford() checks if this_object() can afford a price, it returns:
//
//	0:	cannot afford.������
//	1:	can afford with proper money(coins).������,�����㹻���ֽ�
//	2: 	can afford, but don't have enough proper money(coins).������,��û���㹻���ֽ�
//
int can_afford(int amount)
//����Ƿ����㹻��money
{
	int total;
	object gold, silver, coin, small_cash, big_cash, ob;

	ob = this_object();
	gold = present("gold_money", ob);
	//present() - ����Ʒ�ı�ʶ���� (id) Ѱ�����.
	silver = present("silver_money", ob);
	coin = present("coin_money", ob);
	small_cash = present("thousand-cash_money", ob);
	big_cash = present("hundred-cash_money", ob);

	total = 0;
	if(gold)
		total += gold->value();
	if(silver)
		total += silver->value();
	if(coin)
		total += coin->value();

	if(total < amount)
	{
		if(small_cash)
			total += small_cash->value();
		if(big_cash)
			total += big_cash->value();
		if(total < amount)
			return 0;
		else return 2;
	}
	return 1;
}

int pay_money(int amount, int can_cash)
//��Ҹ�Ǯ,return 0Ϊ��������Ǯ������������
//return 2Ϊ���ϵ��ֽ𲻹�
//return 1Ϊ����֧��
//can_cash������Ϊ��ʱ,Ϊ��ʹ����Ʊ�ͽ�Ʊ
{
	int total, bcn, scn, gn, sn, cn, flagm = 0;
	object gold, silver, coin, small_cash, big_cash, ob;

	ob = this_object();
	gold = present("gold_money", ob);
	silver = present("silver_money", ob);
	coin = present("coin_money", ob);
	small_cash = present("thousand-cash_money", ob);
	big_cash = present("hundred-cash_money", ob);

	total = 0;
	if(gold) total += gold->value();
	if(silver) total += silver->value();
	if(coin) total += coin->value();
	if(total < amount) flagm = 1;//˵����Ǯ����
	if(small_cash) total += small_cash->value();
	if(big_cash) total += big_cash->value();

	if(total > amount && !can_cash && flagm) return 2;
	//���㹻��Ǯ,����Ǯ����,�ҶԷ�������Ʊ���Ʊ,���Է���2
	if(total < amount) return 0;
	//Ǯ����,����0

	total -= amount;//ȥ��Ҫ֧����value
	if(!can_cash)
	//�粻��ʹ�ý���Ʊ,��ȥ���ߵļ�ֵ
	{
		if(small_cash) total -= small_cash->value();
		if(big_cash) total -= big_cash->value();
	}
	else
	{
		bcn = total/1000000;
		total -= bcn*1000000;
		scn = total/100000;
		total -= scn*100000;
		if(big_cash) big_cash->set_amount(bcn);
		else if(bcn)
		{
			big_cash = new("clone/money/hundred-cash");
			big_cash->set_amount(bcn);
			big_cash->move(ob);
		}
		if(small_cash) small_cash->set_amount(scn);
		else if(scn)
		{
			small_cash = new("clone/money/thousand-cash");
			small_cash->set_amount(scn);
			small_cash->move(ob);
		}
	}
	gn = total/10000;
	total -= gn*10000;
	sn = total/100;
	cn = total-sn*100;

	if(gold) gold->set_amount(gn);
	else if(gn)
	{
		gold = new("clone/money/gold");
		gold->set_amount(gn);
		gold->move(ob);
	}
	if(silver) silver->set_amount(sn) ;
	else if(sn > 0)
	{
		silver = new("clone/money/silver");
		silver->set_amount(sn);
		silver->move(ob);
	}
	if( coin ) coin->set_amount(cn);
	else if(cn > 0)
	{
		coin = new("clone/money/coin");
		coin->set_amount(cn);
		coin->move(ob);
	}
	return 1;
}
void get_money(int amount)
//�������money
{
	int v;
	object ob, me;

	me = this_object();
	if(amount < 1)
		amount = 1;
	if(v = amount/1000000)
	{
		ob = new("clone/money/hundred-cash");
		ob->set_amount(v);
		ob->move(me);
		amount %= 1000000;
	}
	if(v = amount/100000)
	{
		ob = new("clone/money/thousand-cash");
		ob->set_amount(v);
		ob->move(me);
		amount %= 100000;
	}
	if(v = amount/10000)
	{
		ob = new("clone/money/gold");
		ob->set_amount(v);
		ob->move(me);
		amount %= 10000;
	}
	if(v = amount/100)
	{
		ob = new("clone/money/silver");
		ob->set_amount(v);
		ob->move(me);
		amount %= 100;
	}
	if(amount)
	{
		ob = new("clone/money/coin");
		ob->set_amount(amount);
		ob->move(me);
	}
}
